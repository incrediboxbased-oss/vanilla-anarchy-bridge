package oss.vanilla.bridge;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class VABClient implements ClientModInitializer {
    private static KeyBinding openDiagnostics;

    @Override
    public void onInitializeClient() {
        BridgeLog.info("VAB 0.2.0 initialized");
        openDiagnostics = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.vab.open_diagnostics", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, "category.vab"));

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> BridgeLog.info("Connected to a world/server"));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> BridgeLog.info("Disconnected from world/server"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openDiagnostics.wasPressed()) {
                if (client.player != null) client.setScreen(new DiagnosticsScreen());
            }
        });
    }
}
