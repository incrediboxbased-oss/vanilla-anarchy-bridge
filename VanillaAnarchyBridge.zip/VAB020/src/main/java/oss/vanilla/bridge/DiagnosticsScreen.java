package oss.vanilla.bridge;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class DiagnosticsScreen extends Screen {
    public DiagnosticsScreen() { super(Text.literal("VAB Diagnostics")); }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        int center = this.width / 2;
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Vanilla Anarchy Bridge 0.2.0"), center, 30, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Client diagnostics only"), center, 48, 0xAAAAAA);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Minecraft: 1.21.1"), center, 72, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("World: " + (client != null && client.isIntegratedServerRunning() ? "Singleplayer / integrated" : client != null && client.player != null ? "Multiplayer" : "Not connected")), center, 92, 0xFFFFFF);
        String server = "Server: " + (client != null && client.getCurrentServerEntry() != null ? client.getCurrentServerEntry().address : client != null && client.isIntegratedServerRunning() ? "Integrated server" : "None");
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(server), center, 112, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("VAB does not alter inventory or network packets."), center, 140, 0xFFCC66);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Press ESC to close"), center, this.height - 24, 0xAAAAAA);
        super.render(context, mouseX, mouseY, delta);
    }
}
