# Vanilla Anarchy Bridge 0.2.0

A client-only Fabric 1.21.1 diagnostics scaffold. Press **R** to open diagnostics.

This version logs world join/disconnect and shows whether the session is singleplayer, multiplayer, or disconnected. It intentionally does not modify inventory packets, server validation, item IDs, or server-side gameplay.

## Build
Use the repository's GitHub Actions workflow to build from this ZIP.
