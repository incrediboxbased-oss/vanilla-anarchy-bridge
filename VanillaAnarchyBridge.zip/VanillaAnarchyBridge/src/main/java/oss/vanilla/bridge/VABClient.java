package oss.vanilla.bridge;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class VABClient implements ClientModInitializer {
    private static KeyBinding openDiagnostics;

    @Override
    public void onInitializeClient() {
        BridgeLog.info("Client initialized");
        openDiagnostics = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.vab.open_diagnostics",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R,
                "category.vab"
        ));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openDiagnostics.wasPressed()) {
                if (client.player != null) {
                    client.player.sendMessage(Text.literal("[VAB] Diagnostics scaffold active. R pressed."), false);
                    BridgeLog.info("Diagnostics key pressed");
                }
            }
        });
    }
}
