package oss.vanilla.bridge;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class BridgeLog {
    private static final Logger LOGGER = LoggerFactory.getLogger("VanillaAnarchyBridge");
    private BridgeLog() {}
    public static void info(String message) { LOGGER.info(message); }
    public static void warn(String message) { LOGGER.warn(message); }
}
