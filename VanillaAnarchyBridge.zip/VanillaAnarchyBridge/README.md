# Vanilla Anarchy Bridge — scaffold

Client-only Fabric 1.21.1 starter project. This first scaffold is intentionally limited to a keybinding and diagnostic logging.

## Build

Build in GitHub Actions using the workflow in `.github/workflows/build.yml` or with Gradle 8.10+ and Java 21:

```sh
gradle build
```

The output JAR is in `build/libs/`.

## Test

Install the built JAR with Fabric Loader and Fabric API on a Minecraft 1.21.1 client. Press **R** in-game to print a test message and log event. This is only a scaffold; it does not inject modded blocks/items or bypass server validation.
