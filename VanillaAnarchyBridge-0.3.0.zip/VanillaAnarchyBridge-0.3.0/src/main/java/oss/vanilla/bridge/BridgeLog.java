package oss.vanilla.bridge;

import java.util.logging.Logger;

public final class BridgeLog {
    private static final Logger LOGGER = Logger.getLogger("VAB");
    private BridgeLog() {}
    public static void info(String message) { LOGGER.info("[VAB] " + message); }
    public static void warn(String message) { LOGGER.warning("[VAB] " + message); }
}
