package oss.vanilla.bridge;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class VABClient implements ClientModInitializer {
    private static KeyBinding diagnosticsKey;
    private static boolean enabled = true;

    @Override
    public void onInitializeClient() {
        BridgeLog.info("VAB 0.3.0 initialized.");
        diagnosticsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.vab.toggle_diagnostics", InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_R, "category.vab"
        ));

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) ->
            BridgeLog.info("Joined world/server. Diagnostics active.")
        );
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) ->
            BridgeLog.info("Disconnected from world/server.")
        );

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (diagnosticsKey.wasPressed()) {
                enabled = !enabled;
                String state = enabled ? "ON" : "OFF";
                BridgeLog.info("Diagnostics toggled " + state);
                if (client.player != null)
                    client.player.sendMessage(Text.literal("[VAB] Diagnostics " + state), false);
            }
            if (enabled && client.player != null && client.world != null) {
                // Low-frequency state snapshot; no packet interception or modification.
                if (client.player.age % 200 == 0) {
                    BridgeLog.info("Snapshot: dimension=" + client.world.getRegistryKey()
                        + ", playerTick=" + client.player.age
                        + ", position=" + client.player.getBlockPos());
                }
            }
        });
    }
}
