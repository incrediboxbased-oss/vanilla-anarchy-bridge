# Vanilla Anarchy Bridge (VAB) 0.3.0

Fabric client-only diagnostic scaffold for Minecraft 1.21.1.

## Scope
- Toggle low-frequency diagnostic logging with **R**.
- Log join/disconnect events and periodic player/world snapshots.
- No packet interception, alteration, replay, or server-validation bypass.

## Build
Java 21 and Gradle are required:
`gradle build`

The GitHub Actions workflow builds and verifies the remapped JAR.
